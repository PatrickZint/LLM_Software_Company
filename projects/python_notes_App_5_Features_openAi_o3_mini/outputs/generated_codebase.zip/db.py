import sqlite3
import os
import json
from datetime import datetime

from config import CONFIG

DB_PATH = CONFIG['database']['path']

# Ensure that the database directory exists
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)


def get_connection():
    conn = sqlite3.connect(DB_PATH, detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables():
    conn = get_connection()
    cursor = conn.cursor()

    # Create Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL
        );
    ''')

    # Create Notes table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS Notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            categories TEXT,
            tags TEXT,
            user_id INTEGER NOT NULL,
            FOREIGN KEY (user_id) REFERENCES Users(id)
        );
    ''')

    conn.commit()
    conn.close()


# Utility functions for Note operations

def create_note(title, content, categories, tags, user_id):
    conn = get_connection()
    cursor = conn.cursor()
    timestamp = datetime.now()
    # Store categories and tags as JSON strings
    categories_json = json.dumps(categories) if categories else json.dumps([])
    tags_json = json.dumps(tags) if tags else json.dumps([])
    cursor.execute('''
        INSERT INTO Notes (title, content, timestamp, categories, tags, user_id)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (title, content, timestamp, categories_json, tags_json, user_id))
    conn.commit()
    conn.close()


def get_notes(user_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM Notes WHERE user_id = ? ORDER BY timestamp DESC
    ''', (user_id,))
    notes = cursor.fetchall()
    conn.close()
    return notes


def update_note(note_id, title, content, categories, tags):
    conn = get_connection()
    cursor = conn.cursor()
    timestamp = datetime.now()
    categories_json = json.dumps(categories) if categories else json.dumps([])
    tags_json = json.dumps(tags) if tags else json.dumps([])
    cursor.execute('''
        UPDATE Notes SET title = ?, content = ?, timestamp = ?, categories = ?, tags = ? WHERE id = ?
    ''', (title, content, timestamp, categories_json, tags_json, note_id))
    conn.commit()
    conn.close()


def delete_note(note_id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM Notes WHERE id = ?', (note_id,))
    conn.commit()
    conn.close()


def search_notes(user_id, keyword):
    conn = get_connection()
    cursor = conn.cursor()
    pattern = f'%{keyword}%'
    cursor.execute('''
        SELECT * FROM Notes 
        WHERE user_id = ? AND (title LIKE ? OR content LIKE ? OR categories LIKE ? OR tags LIKE ?)
        ORDER BY timestamp DESC
    ''', (user_id, pattern, pattern, pattern, pattern))
    results = cursor.fetchall()
    conn.close()
    return results
