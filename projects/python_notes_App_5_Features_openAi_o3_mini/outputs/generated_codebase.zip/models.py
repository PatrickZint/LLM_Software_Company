from dataclasses import dataclass, field
from datetime import datetime
from typing import List
import json


@dataclass
class User:
    id: int
    username: str
    password_hash: str


@dataclass
class Note:
    id: int = None
    title: str = ''
    content: str = ''
    timestamp: datetime = field(default_factory=datetime.now)
    categories: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    user_id: int = None

    @classmethod
    def from_row(cls, row):
        return cls(
            id=row['id'],
            title=row['title'],
            content=row['content'],
            timestamp=row['timestamp'],
            categories=json.loads(row['categories']) if row['categories'] else [],
            tags=json.loads(row['tags']) if row['tags'] else [],
            user_id=row['user_id']
        )
