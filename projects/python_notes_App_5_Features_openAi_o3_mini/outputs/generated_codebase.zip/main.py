import tkinter as tk
from tkinter import ttk

from db import create_tables
from ui import LoginWindow, NotesApp


def start_notes_app(user):
    # Destroy the login window and open the notes app
    for widget in root.winfo_children():
        widget.destroy()
    app = NotesApp(root, user)


if __name__ == '__main__':
    # Create database tables if they don't exist
    create_tables()

    root = tk.Tk()
    root.geometry('800x600')
    # Use themed widgets
    ttk.Style().theme_use('clam')

    # Start with the login window
    login = LoginWindow(root, on_login_success=start_notes_app)

    root.mainloop()
