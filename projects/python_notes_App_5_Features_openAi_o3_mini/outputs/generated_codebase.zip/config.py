CONFIG = {
    "database": {
        "path": "./data/notes.db"
    },
    "encryption": {
        "algorithm": "Fernet",
        "key_derivation": "PBKDF2",
        "salt": b'random_salt_here',
        "iterations": 100000
    },
    "ui": {
        "theme": "light",
        "default_view": "list"
    },
    "logging": {
        "level": "INFO",
        "file": "./logs/app.log"
    }
}
