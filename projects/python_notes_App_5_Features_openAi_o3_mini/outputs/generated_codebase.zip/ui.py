import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json

from db import create_tables, create_note, get_notes, update_note, delete_note, search_notes
from auth import register_user, authenticate_user


class LoginWindow:
    def __init__(self, master, on_login_success):
        self.master = master
        self.on_login_success = on_login_success
        self.master.title('Login / Register')

        self.frame = ttk.Frame(master, padding="10")
        self.frame.grid(row=0, column=0, sticky='nsew')

        # Username
        ttk.Label(self.frame, text="Username:").grid(row=0, column=0, sticky='w')
        self.username_entry = ttk.Entry(self.frame)
        self.username_entry.grid(row=0, column=1, sticky='ew')

        # Password
        ttk.Label(self.frame, text="Password:").grid(row=1, column=0, sticky='w')
        self.password_entry = ttk.Entry(self.frame, show='*')
        self.password_entry.grid(row=1, column=1, sticky='ew')

        # Buttons
        self.login_button = ttk.Button(self.frame, text="Login", command=self.login)
        self.login_button.grid(row=2, column=0, pady=5)
        self.register_button = ttk.Button(self.frame, text="Register", command=self.register)
        self.register_button.grid(row=2, column=1, pady=5)

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        user = authenticate_user(username, password)
        if user:
            messagebox.showinfo("Success", "Logged in successfully")
            self.on_login_success(user)
        else:
            messagebox.showerror("Error", "Invalid credentials")

    def register(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        if register_user(username, password):
            messagebox.showinfo("Success", "User registered. You can now log in.")
        else:
            messagebox.showerror("Error", "Username already exists")


class NotesApp:
    def __init__(self, master, user):
        self.master = master
        self.user = user
        self.master.title(f"Notes - {self.user['username']}")

        self.frame = ttk.Frame(master, padding="10")
        self.frame.pack(fill='both', expand=True)

        # Search bar
        self.search_var = tk.StringVar()
        search_frame = ttk.Frame(self.frame)
        search_frame.pack(fill='x')
        ttk.Label(search_frame, text="Search:").pack(side='left')
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        self.search_entry.pack(side='left', fill='x', expand=True)
        self.search_entry.bind('<Return>', lambda event: self.perform_search())

        # Notes list
        self.notes_listbox = tk.Listbox(self.frame, height=10)
        self.notes_listbox.pack(fill='both', expand=True)
        self.notes_listbox.bind('<<ListboxSelect>>', self.load_selected_note)

        # Note editor
        self.title_var = tk.StringVar()
        ttk.Label(self.frame, text="Title:").pack(anchor='w')
        self.title_entry = ttk.Entry(self.frame, textvariable=self.title_var)
        self.title_entry.pack(fill='x')
        ttk.Label(self.frame, text="Content:").pack(anchor='w')
        self.content_text = tk.Text(self.frame, height=10)
        self.content_text.pack(fill='both', expand=True)

        # Buttons
        buttons_frame = ttk.Frame(self.frame)
        buttons_frame.pack(fill='x')
        ttk.Button(buttons_frame, text="New Note", command=self.new_note).pack(side='left')
        ttk.Button(buttons_frame, text="Save Note", command=self.save_note).pack(side='left')
        ttk.Button(buttons_frame, text="Delete Note", command=self.delete_note).pack(side='left')
        ttk.Button(buttons_frame, text="Export", command=self.export_notes).pack(side='left')
        ttk.Button(buttons_frame, text="Import", command=self.import_notes).pack(side='left')

        self.selected_note_id = None
        self.load_notes()

    def perform_search(self):
        keyword = self.search_var.get()
        notes = search_notes(self.user['id'], keyword) if keyword else get_notes(self.user['id'])
        self.populate_notes_list(notes)

    def populate_notes_list(self, notes):
        self.notes_listbox.delete(0, tk.END)
        self.notes_data = []
        for note in notes:
            self.notes_listbox.insert(tk.END, note['title'])
            self.notes_data.append(note)

    def load_notes(self):
        notes = get_notes(self.user['id'])
        self.populate_notes_list(notes)

    def load_selected_note(self, event):
        selection = self.notes_listbox.curselection()
        if not selection:
            return
        index = selection[0]
        note = self.notes_data[index]
        self.selected_note_id = note['id']
        self.title_var.set(note['title'])
        self.content_text.delete('1.0', tk.END)
        self.content_text.insert(tk.END, note['content'])

    def new_note(self):
        self.selected_note_id = None
        self.title_var.set("")
        self.content_text.delete('1.0', tk.END)

    def save_note(self):
        title = self.title_var.get()
        content = self.content_text.get('1.0', tk.END).strip()
        if not title or not content:
            messagebox.showerror("Error", "Title and content cannot be empty.")
            return
        if self.selected_note_id:
            update_note(self.selected_note_id, title, content, categories=[], tags=[])
        else:
            create_note(title, content, categories=[], tags=[], user_id=self.user['id'])
        messagebox.showinfo("Success", "Note saved successfully")
        self.load_notes()

    def delete_note(self):
        if self.selected_note_id:
            delete_note(self.selected_note_id)
            messagebox.showinfo("Success", "Note deleted")
            self.new_note()
            self.load_notes()
        else:
            messagebox.showerror("Error", "No note selected")

    def export_notes(self):
        notes = get_notes(self.user['id'])
        export_data = []
        for note in notes:
            export_data.append({
                'id': note['id'],
                'title': note['title'],
                'content': note['content'],
                'timestamp': str(note['timestamp']),
                'categories': note['categories'],
                'tags': note['tags']
            })
        file_path = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('JSON Files', '*.json')])
        if file_path:
            with open(file_path, 'w') as f:
                json.dump(export_data, f, indent=4)
            messagebox.showinfo("Export", "Notes exported successfully.")

    def import_notes(self):
        file_path = filedialog.askopenfilename(filetypes=[('JSON Files', '*.json')])
        if file_path:
            with open(file_path, 'r') as f:
                try:
                    imported_notes = json.load(f)
                    for note in imported_notes:
                        # Here we assume no duplicates; production code should check for duplicates
                        create_note(note.get('title', 'Untitled'), note.get('content', ''), 
                                    categories=json.loads(note.get('categories', '[]')) if note.get('categories') else [], 
                                    tags=json.loads(note.get('tags', '[]')) if note.get('tags') else [], 
                                    user_id=self.user['id'])
                    messagebox.showinfo("Import", "Notes imported successfully.")
                    self.load_notes()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to import notes: {e}")
